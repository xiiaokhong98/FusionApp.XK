

--[[
By小珍
QQ号：715215876
QQ群：436144129

更名为load.lua放到工程源码里

调用方法：

import "load"
监控下载()

]]


function 监控下载()
require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.support.*"

--修复软件漏洞
local hh={};webView.addJavascriptInterface(hh,'JsInterface');
local dump=nil;webView.addJavascriptInterface({},'JsInterface')

local function decodeURL(s)
  local s = string.gsub(s, '%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)
  return s
end

--文件缓存路径
下载目录=Environment.getExternalStorageDirectory().toString().."/Download/"

function 安装软件(安装包路径uri)
  import"java.net.URLDecoder"
  intent = Intent(Intent.ACTION_VIEW)
  intent.setDataAndType(安装包路径uri, "application/vnd.android.package-archive")
  intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  activity.startActivity(intent)
end

function xdc(url,path)
  require"import"
  import"java.net.URL"
  local ur =URL(url)
  import"java.io.File"
  file =File(path);
  local con = ur.openConnection();
  --con.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; U; Android 6.0.1; zh-cn; OPPO R9s Plus Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/53.0.2785.134 Mobile Safari/537.36 OppoBrowser/4.9.3")
  --con.setRequestProperty("Host","streamoc.music.tc.qq.com")
  --con.setRequestProperty("Connection","keep-alive")
  --con.setRequestProperty("Accept-Encoding","gzip, deflate")
  local co = con.getContentLength();
  local is = con.getInputStream();
  local bs = byte[1024]
  local len,read=0,0
  import"java.io.FileOutputStream"
  local wj= FileOutputStream(path);
  len = is.read(bs)
  while len~=-1 do
    wj.write(bs, 0, len);
    read=read+len
    pcall(call,"ding",read,co)
    len = is.read(bs)
  end
  wj.close();
  is.close();
  pcall(call,"dstop",co)

end
function appDownload(url,path)
  thread(xdc,url,path)
end

function 件内下载(title,url,path)
  local ts=true
  local wl=activity.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE).getActiveNetworkInfo();
  if wl== nil then
    print("无法连接到服务器，请检查网络")
  else
    appDownload(url,path)
  end
  local layout={
    LinearLayout;
    layout_height="fill";
    layout_width="fill";
    orientation="vertical";
    {
      LinearLayout;
      layout_height="5dp";
      layout_width="fill";
      background="#FF3C8BDA";
    },
    {
      LinearLayout;
      orientation='vertical';--纵向或横向
      layout_width="fill";
      layout_height="fill";
      layout_gravity="center";--重力属性
      ScrollView,--纵向滑动
      VerticalScrollBarEnabled=false;--隐藏纵向滑条
      layout_marginTop="0dp",
    };
    {
      LinearLayout;
      layout_width="fill";
      layout_height="28dp";
      orientation="horizontal";
      gravity="center";
      {
        TextView;
        textSize="18sp";
        text="提示";
        gravity="center";
        textStyle="bold";
        layout_width="fill";
        layout_height="wrap";
      };
    };
    {
      LinearLayout;
      layout_height="fill";
      layout_width="fill";
      gravity="center",
      {
        TextView;--钮扣
        text="";--文本
        textSize="15";--文本大小
        textColor="#FF000000";
        layout_width="-1";--宽度
        layout_height="1dp";
        backgroundColor="#FFF3F3F3";--背景色
      };
    };
    {
      LinearLayout;
      layout_width="fill";
      layout_height="wrap";
      orientation="vertical";
      {
        TextView;
        text="文件名称："..title;
        layout_width="fill";
        layout_height="wrap";
        layout_marginTop="5dp";
        layout_marginRight="15dp";
        layout_marginLeft="15dp";
        layout_marginBottom="15dp";
        textSize="15sp";
      };
      {
        TextView;
        id="appdowninfo";
        text="已经下载：0MB/0MB\n\n下载状态：准备下载...";
        layout_width="fill";
        layout_height="wrap";
        layout_marginRight="15dp";
        layout_marginLeft="15dp";
        layout_marginBottom="15dp";
        textSize="15sp";
      };
      {
        ProgressBar;
        id="进度条";
        progress=0,
        style="?android:attr/progressBarStyleHorizontal";
        layout_width="fill";
        layout_height="wrap";
        layout_marginRight="15dp";
        layout_marginLeft="15dp";
        layout_marginBottom="15dp";
      };
    };
    {
      LinearLayout;
      layout_height="fill";
      layout_width="fill";
      gravity="center",
      {
        TextView;--钮扣
        text="";--文本
        textSize="15";--文本大小
        textColor="#FF000000";
        layout_width="-1";--宽度
        layout_height="1dp";
        backgroundColor="#FFF3F3F3";--背景色
      };
    };
    {
      LinearLayout;
      layout_width="fill";
      layout_height="wrap";
      orientation="horizontal";
      {
        FrameLayout;
        layout_width="fill";
        layout_height="wrap";
        layout_weight="1";
        id="openfile";
        visibility=0,
        {
          TextView;
          id="打开文件";
          text="";
          textColor="#FF3C8BDA";
          style="?android:attr/buttonBarButtonStyle";
          layout_width="wrap";
          layout_height="wrap";
          gravity="center";
          layout_gravity="center";
        };
      };
      {
        TextView;--钮扣
        text="";--文本
        textSize="15";--文本大小
        textColor="#FF000000";
        layout_width="1dp";--宽度
        layout_height="-1";
        backgroundColor="#FFF3F3F3";--背景色
      };
      {
        FrameLayout;
        layout_width="fill";
        layout_height="wrap";
        layout_weight="1";
        {
          TextView;
          id="后台下载";
          text="后台下载";
          textColor="#FF3C8BDA";
          style="?android:attr/buttonBarButtonStyle";
          layout_width="wrap";
          layout_height="wrap";
          gravity="center";
          layout_gravity="center";
        };
      };
    };
  };


  dldown=LuaDialog(this)
  --.setTitle("标题")

  dldown.setView(loadlayout(layout))
  --.setPositiveButton("确定",{onClick=function(v) print(edit.Text)end})
  --.setNegativeButton("取消",nil)
  .setCanceledOnTouchOutside(false)
  .setCancelable(true)
  dldown.show()
  import "android.graphics.drawable.ColorDrawable"
  --dialog1.getWindow().setBackgroundDrawable(ColorDrawable(0x00000000));


  进度条.ProgressDrawable.setColorFilter(PorterDuffColorFilter(0xFF3C8BDA,PorterDuff.Mode.SRC_ATOP))

  function ding(a,b)--已下载，总长度(byte)
    appdowninfo.Text="下载进度："..string.format("%0.2f",a/1024/1024).."MB/"..string.format("%0.2f",b/1024/1024).."MB".."\n\n下载状态：正在下载..."
    进度条.progress=(a/b*100)
  end

  function dstop(c)--总长度
    if ts then
      appdowninfo.Text="文件大小："..string.format("%0.2f",c/1024/1024).."MB".."\n\n下载目录："..下载目录
      后台下载.setText("下载完成")
      打开文件.setText("打开文件")
      luajava.clear(ts)
      打开文件.setVisibility(View.VISIBLE)
    else
      print(title.."已下载")
      luajava.clear(ts)
      打开文件.setVisibility(View.VISIBLE)
    end
  end

  后台下载.onClick=function()
    dldown.dismiss()
    luajava.clear(dldown,布局)
    ts=nil
    if 后台下载.getText()=="后台下载" then
      print("正在下载...")
    end
  end

  打开文件.onClick=function()
    dldown.dismiss()
      安装软件(Uri.parse("file://"..path))
  end

  if 打开文件.Text~=nil then
    打开文件.setVisibility(View.GONE)
  end

end

import("android.text.format.Formatter")
webView.setDownloadListener({
  onDownloadStart = function(url, userAgent, contentDisposition, mimetype, contentLength)
    文件名称= decodeURL(URLUtil.guessFileName(url, contentDisposition, mimeType)):gsub("-","_"):gsub(" ","_"):gsub("、","_")
    文件链接 = decodeURL(url)
    文件类型 = mimetype
    文件大小 = Formatter.formatFileSize(this, contentLength)
    local DownloadLoyout={
      LinearLayout;
      layout_height="fill";
      layout_width="fill";
      orientation="vertical";
      {
        LinearLayout;
        layout_height="5dp";
        layout_width="fill";
        background="#FF3C8BDA";
      },
      {
        LinearLayout;
        layout_height="28dp";
        layout_width="fill";
        orientation="horizontal";
        gravity="center";
        {
          TextView;
          textSize="18sp";
          text="提示";
          gravity="center";
          textStyle="bold",
        };
      },
      {
        LinearLayout;
        layout_height="fill";
        layout_width="fill";
        orientation="horizontal";
        {
          TextView;--钮扣
          text="";--文本
          textSize="15";--文本大小
          textColor="#FF000000";
          layout_width="-1";--宽度
          layout_height="1dp";
          backgroundColor="#FFF3F3F3";--背景色
        };
      };
      {
        LinearLayout;
        layout_height="fill";
        layout_width="fill";
        orientation="horizontal";
        {
          TextView;
          id="内容";
          text= "文件名称："..文件名称.."\n\n文件大小："..文件大小.."\n\n文件类型："..文件类型.."\n\n下载链接："..文件链接;--显示的文字
          layout_width="fill";
          layout_height="wrap";
          layout_marginTop="5dp";
          layout_marginRight="15dp";
          layout_marginLeft="15dp";
          layout_marginBottom="15dp";
          textSize="15sp"; 
        }
      };
      {
        LinearLayout;
        layout_height="fill";
        layout_width="fill";
        gravity="center",
        {
          TextView;--钮扣
          text="";--文本
          textSize="15";--文本大小
          textColor="#FF000000";
          layout_width="-1";--宽度
          layout_height="1dp";
          backgroundColor="#FFF3F3F3";--背景色
        };
      };
      {
        LinearLayout;
        layout_height="48dp";
        layout_width="fill";
        orientation="horizontal";
        {
          FrameLayout;
          layout_height="fill";
          layout_width="fill";
          layout_weight="1";
          {
            TextView;
            id="消极按钮";
            text="取消下载";
            textColor="#FF3C8BDA";
            layout_height="fill";
            layout_width="fill";
            textStyle="bold";
            gravity="center";
          }
        };
        {
          TextView;--钮扣
          text="";--文本
          textSize="15";--文本大小
          textColor="#FF000000";
          layout_width="1dp";--宽度
          layout_height="-1";
          backgroundColor="#FFF3F3F3";--背景色
        };
        {
          FrameLayout;
          layout_height="fill";
          layout_width="fill";
          layout_weight="1";
          {
            TextView;
            id="中立按钮";
            text="外置浏览器";
            textColor="#FF3C8BDA";
            textStyle="bold";
            layout_height="fill";
            layout_width="fill";
            gravity="center";
          }
        };
        {
          TextView;--钮扣
          text="";--文本
          textSize="15";--文本大小
          textColor="#FF000000";
          layout_width="1dp";--宽度
          layout_height="-1";
          backgroundColor="#FFF3F3F3";--背景色
        };
        {
          FrameLayout;
          layout_height="fill";
          layout_width="fill";
          layout_weight="1";
          {
            TextView;
            id="积极按钮";
            text="自带下载器";
            textColor="#FF3C8BDA";
            layout_height="fill";
            layout_width="fill";
            textStyle="bold";
            gravity="center";
          }
        };
      }
    }
    Dialog1=LuaDialog(this)
    --.setTitle("标题")
    Dialog1.setView(loadlayout(DownloadLoyout))
    --.setPositiveButton("确定",{onClick=function(v) print(edit.Text)end})
    --.setNegativeButton("取消",nil)
    .setCanceledOnTouchOutside(false)
    .setCancelable(true)
    Dialog1.show()
    import "android.graphics.drawable.ColorDrawable"
    --dialog1.getWindow().setBackgroundDrawable(ColorDrawable(0x00000000));
    --函数
    function 波纹(id,颜色)
      import "android.content.res.ColorStateList"
      local attrsArray = {android.R.attr.selectableItemBackgroundBorderless} 
      local typedArray =activity.obtainStyledAttributes(attrsArray) 
      ripple=typedArray.getResourceId(0,0) 
      Pretend=activity.Resources.getDrawable(ripple) 
      Pretend.setColor(ColorStateList(int[0].class{int{}},int{颜色}))
      id.setBackground(Pretend.setColor(ColorStateList(int[0].class{int{}},int{颜色})))
    end
    --用法
    波纹(积极按钮,0xFF84B1ED)
    波纹(中立按钮,0xFF84B1ED)
    波纹(消极按钮,0xFF84B1ED)
    消极按钮.onClick=function(v)
      Dialog1.dismiss()
      弹出消息("你好狠心居然残忍的拒绝了我!呜呜呜(┯_┯)")
    end
    中立按钮.onClick=function(v)
      Dialog1.dismiss()
      import "android.content.Intent"
      import "android.net.Uri"
      viewIntent = Intent("android.intent.action.VIEW",Uri.parse(文件链接))
      activity.startActivity(viewIntent)
      弹出消息("正在调用外置浏览器一窝一窝的下崽中请稍候... 嘻嘻嘻(๑ᵔ⌔ᵔ๑)")
    end
    积极按钮.onClick=function(v)
      Dialog1.dismiss()
      if 下载目录~=nil then
        local 下载目录=下载目录..文件名称
        软件内下载(文件名称,文件链接,下载目录)
        弹出消息("正在使用内置下载器一窝一窝的下崽中请稍候... 嘻嘻嘻(๑ᵔ⌔ᵔ๑)")
      end
    end
  end
})
end