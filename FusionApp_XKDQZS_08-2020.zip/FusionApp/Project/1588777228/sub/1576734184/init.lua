template="tool"
name="B2 精选内容"
