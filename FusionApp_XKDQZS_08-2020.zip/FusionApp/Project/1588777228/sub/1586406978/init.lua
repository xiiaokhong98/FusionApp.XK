name="设备桌面壁纸"
template="tool"
