template="tool"
appcode="200801"
packagename="com.xkdqzs.zysc"
appname="资源市场"
user_permission={
  [1]	= "ACCESS_COARSE_LOCATION" ;
  [2]	= "ACCESS_FINE_LOCATION" ;
  [3]	= "ACCESS_NETWORK_STATE" ;
  [4]	= "ACCESS_WIFI_STATE" ;
  [5]	= "INTERNET" ;
  [6]	= "WRITE_EXTERNAL_STORAGE" ;
  } ;
appver="2.2"
