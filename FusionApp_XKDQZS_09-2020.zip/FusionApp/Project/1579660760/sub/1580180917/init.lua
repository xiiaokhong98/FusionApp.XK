template="tool"
name="默认播放器"
