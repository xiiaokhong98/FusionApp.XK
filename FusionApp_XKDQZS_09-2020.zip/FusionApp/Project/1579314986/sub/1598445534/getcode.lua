require "import" 
import "android.widget.*" 
import "android.view.*"
import "milkpotatoes"

function getAuthCode()
--[[
#获取激活码的方法
在这里填写联系你的代码
或者打开你的网站的代码
我已经内置了几种常用的代码
#联系QQ
qq_person()
*使用方法
qq_person(QQ号)
如qq_person(1398042040)
*
#添加QQ群
qq_group()
*使用方法
qq_group(QQ群号)
如qq_group(599477462)
*
#添加telegram/通过telegram进行建议
viatelegram()
*使用方法
viatelegram(用户id/群id)
使用该方法进入群，需要该群设置有效的id
如viatelegran(stusp)
*
#通过浏览器打开链接
openInBrowser()
*使用方法
openInBrowser(网址)
如openInBrowser("http://www.milkpotatoes.cn/")
*
#发送邮件
sendmail()
*使用方法
sendmail(邮箱地址,标题,内容)
如sendmail("milkpotatoes@outlook.com", "感谢", "Thanks for your auth code")
*
#复制文本
copytext()
*使用方法
copytext(文本)
将文本写入剪贴板
可以配合print()进行提示
如copytext("http://www.milkpotatoes.cn/")
*
#其他说明
如果这里的代码为空，用户在点击获取激活码的按钮将会出现无响应
你也可以使用对话框以实现多重联系方式的显示，让用户自行选择
]]
sendmail("wuikhong07121998@gmail.com", "成人资源助手", "获取注册码！日期：00/00/2020")
end
