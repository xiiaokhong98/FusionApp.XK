template="tool"
name="聊天宝典"
