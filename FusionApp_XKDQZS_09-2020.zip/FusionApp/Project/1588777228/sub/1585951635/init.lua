name="设备信息"
template="tool"
