template="tool"
name="B2 小康频道"
