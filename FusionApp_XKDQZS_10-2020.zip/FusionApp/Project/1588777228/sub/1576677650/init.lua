template="tool"
name="关于小康助手"
