
--导入必备模块
require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.media.MediaPlayer"
import "android.view.GestureDetector"
import "java.io.File"
import "android.content.res.Configuration"
import "android.content.Context"
import "android.media.AudioManager"
import "android.support.v7.widget.CardView"
import "android.media.AudioManager"
import "android.graphics.drawable.GradientDrawable"
import "android.content.*" 


锁定=0
focusdelay=3
function 播放(name,path)



  activity.setContentView(loadlayout("MPlayerLayout"))
  window=activity.getWindow()
  window.setNavigationBarColor(0xFF000000)
  ProgressBar.IndeterminateDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF, PorterDuff.Mode.SRC_ATOP))
  seekBar.ProgressDrawable.setColorFilter(PorterDuffColorFilter(0xfff0f0f4, PorterDuff.Mode.SRC_ATOP))
  seekBar.Thumb.setColorFilter(PorterDuffColorFilter(0xfff0f0f4, PorterDuff.Mode.SRC_ATOP))
  playbitmap=loadbitmap("drawable/video_mid_play_fullscreen.png")
  pausebitmap=loadbitmap("drawable/video_mid_pause_fullscreen.png")
  audiobitmap=loadbitmap("drawable/ic_audio_black_1080dp.png")

  --隐藏状态栏
  this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
  --防止手机休眠
  this.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

  SpeedTable={0.25,0.50,0.75,1.00,1.25,1.50,1.75,2.00}
  SpeedIndex=3

  function 剩余电量()
    import "android.os.BatteryManager"
    --注意：Api>=21
    if tonumber(Build.VERSION.SDK)>=21 then
      local battery = BatteryManager().getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
      return tostring(battery.."%")
    else return "未知电量" end
  end

  --更新时间、电量、网速、进度、eoow优化
  function 更新()

    --存储进度
    if mediaPlayer then
      if mediaPlayer.getCurrentPosition( )>60000 then
        activity.setSharedData(path,mediaPlayer.getCurrentPosition( ))
      end
    end
    --
    TimeBtn.setText(os.date("%H:%M"))
    BatteryBtn.setText(剩余电量())
    --时电
    import "android.net.TrafficStats"
    myTrafficStats = TrafficStats()
    import "android.text.format.Formatter"
    local a,b,c
    a= myTrafficStats.getTotalRxBytes()
    task(200,function()
      b= myTrafficStats.getTotalRxBytes()
      if BufferText.setText then 
        c=Formatter.formatFileSize(activity, (b-a)/0.2).."/s"
        c=c:gsub("千字节","KB"):gsub("兆字节","MB")
        BufferText.setText(c) 
      end
    end)
    --网速
    if focusdelay==0 then
      隐藏菜单()
      if not(isSeekbarTracking) and focus then
        setunfocus()
      end
    else
      focusdelay=focusdelay-1
    end
    if mediaPlayer and mediaPlayer.isPlaying() then
      currentposition=mediaPlayer.getCurrentPosition()
      currenttime.Text=ms2minsec(currentposition)
      if not(isSeekbarTracking) then
        seekBar.setProgress(currentposition)
      end
    end
    --进度条
    task(1000,function()
      更新()
    end)
  end
  更新()
  --毫秒转时:分:秒格式
  function ms2minsec(time)
    local min,sec=0,0
    sec=math.floor(time/1000)
    if(sec>3600) then
      local hour=math.floor(sec/3600)
      min=math.floor(sec/60-hour*60)
      sec=math.floor(sec%60)
      if hour<10 then hour="0"..hour end
      if min<10 then min="0"..min end
      if sec<10 then sec="0"..sec end
      return hour..":"..min..":"..sec
    end
    if(sec>60) then
      min=math.floor(sec/60)
      sec=math.floor(sec%60)
    end
    if min<10 then min="0"..min end
    if sec<10 then sec="0"..sec end
    return min..":"..sec
  end
  --小数转百分数
  function dec2per(n)
    return tointeger(100*n).."%"
  end

  --URL解码，主要用于解码被URL编码的中文
  local function decodeURL(s)
    local s = string.gsub(s, '%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)
    return s
  end

  name=decodeURL(name)
  path=decodeURL(path)

  AWidth=activity.getWidth()
  AHeight=activity.getHeight()


  --由焦点变量focus控制是否显示titlebar，controlbar
  --focusdelay为0时，ti2会隐藏顶栏，底栏，虚拟导航栏，否则每秒-1

  function setunfocus()
    if 锁定==1 then
      focus=true
      focusdelay=3
    else
      focus=false
      titlebar.setVisibility(View.GONE)
      controlbar.setVisibility(View.GONE)
      --activity.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE)
    end
  end

  function setfocus()
    if 锁定==1 then
    else
      focus=true
      titlebar.setVisibility(View.VISIBLE)
      controlbar.setVisibility(View.VISIBLE)
      --activity.getDecorView().setSystemUiVisibility(0)
      --重置focusdelay
      focusdelay=3
    end
  end


  function ChangeSurfaceSize()
    VideoWidth=mediaPlayer.getVideoWidth()
    VideoHeight=mediaPlayer.getVideoHeight()
    scale=math.min(AWidth/VideoWidth,AHeight/VideoHeight)
    layoutParams=mSurfaceView.getLayoutParams()
    layoutParams.width=VideoWidth*scale
    layoutParams.height=VideoHeight*scale
    mSurfaceView.setLayoutParams(layoutParams)
  end

  function onConfigurationChanged(config)
    AWidth=activity.getWidth()
    AHeight=activity.getHeight()
    ChangeSurfaceSize()
  end

  function AutoRotate(VideoWidth,VideoHeight)
    隐藏菜单()
    if VideoWidth>VideoHeight then
      activity.setRequestedOrientation(0)
      directbtn1.setVisibility(View.GONE)
      directbtn2.setVisibility(View.VISIBLE)
    else
      activity.setRequestedOrientation(1)
      directbtn1.setVisibility(View.VISIBLE)
      directbtn2.setVisibility(View.GONE)
    end
  end

  mediaPlayer=MediaPlayer()
  mediaPlayer.reset()
  mediaPlayer.setScreenOnWhilePlaying(true)
  mediaPlayer.setVolume(0.8)

  --缓冲完成的监听
  mediaPlayer.setOnPreparedListener(MediaPlayer.OnPreparedListener{
    onPrepared=function(mediaPlayer)
      --开始播放
      Prepared=true
      playbtn.setEnabled(true)
      seekBar.setEnabled(true)
      VideoWidth=mediaPlayer.getVideoWidth()
      VideoHeight=mediaPlayer.getVideoHeight()
      AutoRotate(VideoWidth,VideoHeight)
      videoduration=mediaPlayer.Duration
      seekBar.setMax(videoduration)
      endtime.Text=ms2minsec(videoduration)
      ChangeSurfaceSize()
      if isNetFile then
        BufferMsg.setVisibility(View.GONE)
      end
      if ms2minsec(videoduration) == "0-1:59" then
        endtime.Text="直播"
      else
        endtime.Text=ms2minsec(videoduration)
      end
      --设置名称
      if mediaPlayer.getVideoWidth()<720 then
        Clear="流畅"
      end
      if mediaPlayer.getVideoWidth()>=720 and mediaPlayer.getVideoWidth()<1280 then
        Clear="标清"
      end
      if mediaPlayer.getVideoWidth()>=1280 and mediaPlayer.getVideoWidth()<1920 then
        Clear="高清"
      end
      if mediaPlayer.getVideoWidth()>=1920 then
        Clear="超清"
      end
      if mediaPlayer.getVideoWidth()>=1920 and mediaPlayer.getVideoHeight()>=1080 then
        Clear="蓝光"
      end
      if name=="" then
        title.Text=File(path).Name.."("..Clear..")"
      else
        title.Text=name.."("..Clear..")"
      end
      Play()
      --定位观看
      task(100,function()
        if activity.getSharedData(path)~=nil then
          BufferMsg.setVisibility(View.VISIBLE)
          print("已定位上次观看 "..ms2minsec(activity.getSharedData(path)))
          mediaPlayer.seekTo(math.ceil(activity.getSharedData(path)-10000))
        end
      end)
    end
  })

  --进度跳转完成监听
  mediaPlayer.setOnSeekCompleteListener(MediaPlayer.OnSeekCompleteListener{
    onSeekComplete=function(mediaPlayer)
      BufferMsg.setVisibility(View.GONE)--跳转完成
    end
  })

  --网络流媒体的缓冲变化时回调
  mediaPlayer.setOnBufferingUpdateListener(MediaPlayer.OnBufferingUpdateListener{
    onBufferingUpdate=function(mediaPlayer,BufferPercent)
      seekBar.setSecondaryProgress(BufferPercent/100*videoduration)
    end
  })

  --播放完成回调
  mediaPlayer.setOnCompletionListener(MediaPlayer.OnCompletionListener{
    onCompletion=function(mediaPlayer)
      if Prepared then
        playbtn.setImageBitmap(playbitmap)
        --播放完毕的时间偶尔会达不到总时长，需要在完成监听里纠正
        currenttime.Text=ms2minsec(videoduration)
        if ms2minsec(videoduration) == "0-1:59" then
          endtime.Text="直播"
        else
          endtime.Text=ms2minsec(videoduration)
        end
        if ms2minsec(videoduration) == endtime.text then
          print("播放完毕")
        end
      end
    end
  })

  mediaPlayer.setOnInfoListener(MediaPlayer.OnInfoListener{
    onInfo=function(mediaPlayer,what,extra)
      if what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START then
      elseif what == MediaPlayer.MEDIA_INFO_BUFFERING_START then
        if isNetFile then
          BufferMsg.setVisibility(View.VISIBLE)--进度开
        end
      elseif what == MediaPlayer.MEDIA_INFO_BUFFERING_END then
        if isNetFile then
          BufferMsg.setVisibility(View.GONE)
        end
      end
    end
  })

  --错误回调
  mediaPlayer.setOnErrorListener(MediaPlayer.OnErrorListener{
    onError=function(mediaPlayer,what,extra)
      if what == MediaPlayer.MEDIA_ERROR_UNKNOWN then
        print("播放失败 请更换线路")
      else
        if what == MediaPlayer.MEDIA_ERROR_SERVER_DIED then
          print("服务器错误")
        else
        end
      end
    end
  })

  if Build.VERSION.SDK_INT<23 then
    SpeedBtn.setVisibility(View.GONE)
  end
  function ChangePlayerSpeed(speed)
    if Build.VERSION.SDK_INT>=23 then
      if mediaPlayer.isPlaying() then
        mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed))
      else
        mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed))
        mediaPlayer.pause()
      end
    end
  end

  if luajava.bindClass("android.os.Build").VERSION.SDK_INT>=21 then
    activity.setTheme(android.R.style.Theme_Material)
  else
    activity.setTheme(android.R.style.Theme_Holo)
  end

  ti2=Ticker()
  ti2.Period=1000
  ti2.onTick=function()

    if focusdelay==0 then
      if not(isSeekbarTracking) and focus then
        setunfocus()
      end
    else
      focusdelay=focusdelay-1
    end
    if mediaPlayer and mediaPlayer.isPlaying() then
      currentposition=mediaPlayer.getCurrentPosition()
      currenttime.Text=ms2minsec(currentposition)
      if not(isSeekbarTracking) then
        seekBar.setProgress(currentposition)
      end
    end
  end
  pcall(function()ti2.start()end)


  function PreparePlay(path)
    playbtn.setEnabled(false)
    seekBar.setEnabled(false)
    isNetFile=path:find("://")
    if isNetFile then
      BufferMsg.setVisibility(View.VISIBLE)
    end
    Prepared=false
    --设置播放资源
    mediaPlayer.setDataSource(path) 
    --设置名称
    if name=="" then
      title.Text=File(path).Name
    else
      title.Text=name
    end
    videoduration=0
    --开始缓冲资源
    mediaPlayer.prepareAsync()
  end

  holder=mSurfaceView.getHolder()
  holder.addCallback(SurfaceHolder_Callback{
    surfaceCreated=function(holder)
      mediaPlayer.setDisplay(holder)
      if isPlayingWhenDestroyed then
        Play()
      end
    end,
    surfaceDestroyed=function(holder)
      isPlayingWhenDestroyed=mediaPlayer.isPlaying()
      Pause()
    end
  })

  function 设置音量(x) --x：0~100  百分比
    local mAudioManager = activity.getSystemService(Context.AUDIO_SERVICE);
    local maxVolume=mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC, tonumber(x)/100*maxVolume, 0);--设置1显示音量调节窗口，0为隐藏
    mAudioManager,maxVolume=nil
  end
  function 初始音量()
    local mAudioManager = activity.getSystemService(Context.AUDIO_SERVICE);
    local mVolume = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
    local maxVolume=mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    return mVolume/maxVolume
  end

  function getLight()
    local lp=activity.getWindow().getAttributes()
    if lp.screenBrightness<0 then
      --小于0时为默认亮度,不清楚是多少,暂定为0.5
      return 0.5
    else
      return lp.screenBrightness
    end
  end

  --设置窗口亮度
  --0<=brightness<=1
  function setLight(brightness)
    local lp=activity.getWindow().getAttributes()
    lp.screenBrightness=brightness
    activity.getWindow().setAttributes(lp)
  end


  mOnGestureListener=GestureDetector.OnGestureListener{


    onDown=function(e)
      --记录按下时的X坐标，不清楚和下面e1.getX()的区别
      downX=e.getX()
      return true
    end,

    --滑动
    onScroll=function(e1,e2,distanceX,distanceY)

      --注意if执行完以后任然存在ScrollMode=nil的可能
      if not(ScrollMode) then
        --如果ScrollMode为空,那么判断并赋值ScrollMode
        if math.abs(e1.getX()-e2.getX())>math.abs(e1.getY()-e2.getY()) then
          --如果起步时横向滑动大于纵向,那么判定进度拖动
          if Prepared then
            ScrollMode=1
          end
        else
          if downX<AWidth/3 then
            --判定左侧上下滑动
            ScrollMode=2
            --刚开始滑动时获取当前窗口亮度
            screenBrightness=getLight()
          elseif downX>2*AWidth/3 then
            --判定右侧上下滑动
            ScrollMode=3
            mVolume=初始音量()
          end
        end
      end

      --锁屏判断
      if 锁定==1 then
      else

        if ScrollMode == 1 then
          --滑动时保持控制栏区域可见
          if not(focus) then
            setfocus()
          end

          isSeekbarTracking=true
          msg.setVisibility(View.VISIBLE)
          progress=progress-videoduration*distanceX/AWidth/2
          progress=math.max(0,progress)
          progress=math.min(progress,videoduration)
          --会触发seekBar的onProgressChanged
          --但不触发onStopTrackingTouch，所以还要写ACTION_UP事件
          seekBar.setProgress(progress)
        elseif ScrollMode == 2 then
          msg.setVisibility(View.VISIBLE)
          screenBrightness=screenBrightness+distanceY/AHeight*2
          screenBrightness=math.max(0,screenBrightness)
          screenBrightness=math.min(screenBrightness,1)
          msg.setText("亮度\n"..dec2per(screenBrightness))
          --滑动时实时调整亮度
          setLight(screenBrightness)

        elseif ScrollMode == 3 then
          msg.setVisibility(View.VISIBLE)
          mVolume=mVolume+distanceY/AHeight*2
          mVolume=math.max(0,mVolume)
          mVolume=math.min(mVolume,1)
          msg.setText("音量\n"..dec2per(mVolume))
          --滑动时实时调整音量
          设置音量(tointeger(mVolume*100))
        end

      end--锁屏判断

      return true
    end,
  }






  mOnDoubleTapListener=GestureDetector.OnDoubleTapListener{

    --纯单击
    onSingleTapConfirmed=function(e)
      --（通过单击DOWN后300ms没有下一个DOWN事件确认）
      --这不是一个双击事件，而是一个单击事件的时候会回调
      if focus then
        setunfocus()
        隐藏菜单()
      else
        setfocus() 
        显示菜单() 
      end
      return true
    end,


    --纯双击
    onDoubleTap=function(e)
      if Prepared then
        if mediaPlayer.isPlaying() then
          Pause()
           print("已暂停")
        else
          Play()
           print("开始播放")
        end
      end
      return true
    end,
  }





  --一般事件检测
  mGestureDetector=GestureDetector(this,mOnGestureListener)

  --单双击检测
  mGestureDetector.setOnDoubleTapListener(mOnDoubleTapListener)


  fl.onTouch=function(view,event)

    --手指离开屏幕时更改视频进度
    if event.getAction()==MotionEvent.ACTION_UP then
      if ScrollMode then
        ScrollMode=nil
        msg.setVisibility(View.GONE)
      end

      if isSeekbarTracking then
        BufferMsg.setVisibility(View.VISIBLE)--跳转开始
        mediaPlayer.seekTo(progress)
        currenttime.Text=ms2minsec(progress)
        isSeekbarTracking=false
        focusdelay=3
      end
    end

    --把tv的event事件传给mGestureDetector
    --让它来判断事件
    return mGestureDetector.onTouchEvent(event);


  end





  function Play()
    if Prepared then
      mediaPlayer.start()
      playbtn.setImageBitmap(pausebitmap)
    end
  end

  function Pause()
    mediaPlayer.pause()
    playbtn.setImageBitmap(playbitmap)
  end

  playbtn.onClick=function(v)
    focusdelay=3
    if mediaPlayer.isPlaying() then
      Pause()
    else
      Play()
    end
  end

  backbtn.onClick=function(v)
    退出页面()
  end

  TimeBtn.onClick=function(v)
    print("现在时间:"..os.date("%H:%M"))
  end

  BatteryBtn.onClick=function(v)
    print("剩余电量:"..剩余电量())
  end

  directbtn1.onClick=function(v)
    activity.setRequestedOrientation(0)
    directbtn1.setVisibility(View.GONE)
    directbtn2.setVisibility(View.VISIBLE)
  end

  directbtn2.onClick=function(v)
    activity.setRequestedOrientation(1)
    directbtn1.setVisibility(View.VISIBLE)
    directbtn2.setVisibility(View.GONE)
  end

  seekBar.setOnSeekBarChangeListener{
    onStartTrackingTouch=function(seekBar)
      msg.setVisibility(View.VISIBLE)
      isSeekbarTracking=true
      focusdelay=3
    end,
    onProgressChanged=function(seekBar)
      progress=seekBar.getProgress()
      msg.Text="跳转进度\n"..ms2minsec(progress)
    end,
    onStopTrackingTouch=function(seekBar)
      msg.setVisibility(View.GONE)
      mediaPlayer.seekTo(progress)
      currenttime.Text=ms2minsec(progress)
      isSeekbarTracking=false
      focusdelay=3
      BufferMsg.setVisibility(View.VISIBLE)
    end,
  }

  SpeedBtn.onClick=function(v)
    pop=PopupMenu(activity,SpeedBtn)--分别是当前页面和弹窗的父控件
    menu=pop.Menu
    menu.add("0.25").onMenuItemClick=function()
      SpeedIndex=1
      ChangePlayerSpeed(SpeedTable[SpeedIndex])
      SpeedBtn.Text="倍速:"..SpeedTable[SpeedIndex]
      print(SpeedTable[SpeedIndex].."倍速")
    end
    menu.add("0.50").onMenuItemClick=function()
      SpeedIndex=2
      ChangePlayerSpeed(SpeedTable[SpeedIndex])
      SpeedBtn.Text="倍速:"..SpeedTable[SpeedIndex]
      print(SpeedTable[SpeedIndex].."倍速")
    end
    menu.add("0.75").onMenuItemClick=function()
      SpeedIndex=3
      ChangePlayerSpeed(SpeedTable[SpeedIndex])
      SpeedBtn.Text="倍速:"..SpeedTable[SpeedIndex]
      print(SpeedTable[SpeedIndex].."倍速")
    end
    menu.add("1.00").onMenuItemClick=function()
      SpeedIndex=4
      ChangePlayerSpeed(SpeedTable[SpeedIndex])
      SpeedBtn.Text="倍速:"..SpeedTable[SpeedIndex]
      print(SpeedTable[SpeedIndex].."倍速")
    end
    menu.add("1.25").onMenuItemClick=function()
      SpeedIndex=5
      ChangePlayerSpeed(SpeedTable[SpeedIndex])
      SpeedBtn.Text="倍速:"..SpeedTable[SpeedIndex]
      print(SpeedTable[SpeedIndex].."倍速")
    end
    menu.add("1.50").onMenuItemClick=function()
      SpeedIndex=6
      ChangePlayerSpeed(SpeedTable[SpeedIndex])
      SpeedBtn.Text="倍速:"..SpeedTable[SpeedIndex]
      print(SpeedTable[SpeedIndex].."倍速") 
    end
    menu.add("1.75").onMenuItemClick=function()
      SpeedIndex=7
      ChangePlayerSpeed(SpeedTable[SpeedIndex])
      SpeedBtn.Text="倍速:"..SpeedTable[SpeedIndex]
      print(SpeedTable[SpeedIndex].."倍速") 
    end
    menu.add("2.00").onMenuItemClick=function()
      SpeedIndex=8
      ChangePlayerSpeed(SpeedTable[SpeedIndex])
      SpeedBtn.Text="倍速:"..SpeedTable[SpeedIndex]
      print(SpeedTable[SpeedIndex].."倍速") 
    end
    Pause() 
    pop.show()--显示
    Play()
  end

  function 分享(name,url)
    --分享文件
    import "java.io.File"
    if File(url).isFile() then
      import "android.webkit.MimeTypeMap"
      import "android.content.Intent"
      import "android.net.Uri"
      local FileName=tostring(File(url).Name)
      local ExtensionName=FileName:match("%.(.+)")
      local Mime=MimeTypeMap.getSingleton().getMimeTypeFromExtension(ExtensionName)
      local intent = Intent();
      intent.setAction(Intent.ACTION_SEND);
      intent.setType(Mime);
      local file = File(url);
      local uri = Uri.fromFile(file);
      intent.putExtra(Intent.EXTRA_STREAM,uri);
      intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      activity.startActivity(Intent.createChooser(intent, "分享到:"));
      return end

    --分享文字
    import "android.content.*" 
    local text="视频名称："..name.."\n视频地址："..url
    local intent=Intent(Intent.ACTION_SEND); 
    intent.setType("text/plain"); 
    intent.putExtra(Intent.EXTRA_SUBJECT, "分享"); 
    intent.putExtra(Intent.EXTRA_TEXT, text); 
    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
    activity.startActivity(Intent.createChooser(intent,"分享到:")); 
  end 

  MoreBtn.onClick=function(v)--更多
    pop=PopupMenu(activity,MoreBtn)--分别是当前页面和弹窗的父控件
    menu=pop.Menu
    menu.add("分享").onMenuItemClick=function()
      分享(name,path) 
    end
     menu.add("投屏").onMenuItemClick=function()
       import "android.content.Intent"
    import "android.net.Uri"
    viewIntent = Intent("android.intent.action.VIEW",Uri.parse(网页链接))
    activity.startActivity(viewIntent)
  end
    menu.add("画面比例").onMenuItemClick=function()
      items={}
      table.insert(items,tostring("自适应"))
      table.insert(items,tostring("放大裁剪"))
      table.insert(items,tostring("铺满屏幕"))
      AlertDialog.Builder(this)
      .setTitle("画面比例")
      .setItems(items,{onClick=function(l,v)
          if v==0 then
            vh=mediaPlayer.getVideoHeight()
            vw=mediaPlayer.getVideoWidth()
            w=activity.getWidth()--获取屏幕宽
            h=activity.getHeight()--获取屏幕高
            vw=h/vh*vw
            if vw<=w then
              layoutParams = mSurfaceView.getLayoutParams();
              layoutParams.height=h
              layoutParams.width =vw
              mSurfaceView.setLayoutParams(layoutParams);
            else
              vw=mediaPlayer.getVideoWidth()
              layoutParams = mSurfaceView.getLayoutParams();
              layoutParams.height=w/vw*vh
              layoutParams.width =w
              mSurfaceView.setLayoutParams(layoutParams);
            end
          end
          if v==1 then
            vh=mediaPlayer.getVideoHeight()
            vw=mediaPlayer.getVideoWidth()
            w=activity.getWidth()--eoow
            h=activity.getHeight()--获取屏幕高
            vw=h/vh*vw
            if vw>=w then
              layoutParams = mSurfaceView.getLayoutParams();
              layoutParams.height=h
              layoutParams.width =vw
              mSurfaceView.setLayoutParams(layoutParams);
            else
              vw=mediaPlayer.getVideoWidth()
              layoutParams = mSurfaceView.getLayoutParams();
              layoutParams.height=w/vw*vh
              layoutParams.width =w
              mSurfaceView.setLayoutParams(layoutParams);
            end
          end
          if v==2 then
            layoutParams = mSurfaceView.getLayoutParams();
            layoutParams.height=activity.getHeight()
            layoutParams.width =activity.getWidth()
            mSurfaceView.setLayoutParams(layoutParams);
          end
        end})
      .show()
    end

    pop.show()--显示
  end


  function onDestroy()--退出事件
    mediaPlayer.release()
    mediaPlayer=nil
  end

  if not(pcall(PreparePlay,path)) then
    对话框()
    .设置消息("播放失败，播放链接失效或不存在")
    .setCancelable(false)
    .设置积极按钮("确定",function()
      退出页面()
    end)
    .显示()
  end

end

function 显示菜单()
  focus=true
  锁定状态.setVisibility(View.VISIBLE)--显示控件
  --锁屏判断
  if 锁定==1 then
    下载状态.setVisibility(View.GONE)--隐藏控件  
  else 
    下载状态.setVisibility(View.VISIBLE)
  end
  focusdelay=3
end


function 隐藏菜单()
  focus=false
  titlebar.setVisibility(View.GONE)
  controlbar.setVisibility(View.GONE)
  锁定状态.setVisibility(View.GONE)--隐藏控件
  下载状态.setVisibility(View.GONE)--隐藏控件  
  focusdelay=3
end 



function 下载视频()
   对话框()
.设置消息("是否下载，下载仅支持MP4格式，确定下载后注意查看状态栏")
.设置积极按钮("确定",function()
  下载文件(网页链接)
   print("开始下载")
end)
.设置中立按钮("取消",function()
   print("已取消下载")
   end)
.显示()
  if 网页链接:find"://(.-)m3u8" then
    import "android.content.Intent"
    import "android.net.Uri"
    viewIntent = Intent("android.intent.action.VIEW",Uri.parse(网页链接))
    activity.startActivity(viewIntent)
  end
end

--按两次返回退出页面
参数=0
手机主目录=Environment.getExternalStorageDirectory().toString().."/"
function onKeyDown(code,event)
  if string.find(tostring(event),"KEYCODE_BACK") ~= nil then 
    if 参数+2 > tonumber(os.time()) then 
      执行Shell("rm -rf /data/data/"..this.packageName.."/cache/")
      执行Shell("rm -rf /data/user/0/"..this.packageName.."/cache/")
      执行Shell("rm -rf /data/data/"..this.packageName.."/files/data/")
      执行Shell("rm -rf /data/user/0/"..this.packageName.."/files/data/")
      执行Shell("rm -rf "..手机主目录.."/Android/data/"..this.packageName.."/files/")
      activity.finish()
      return true--也同样是消耗掉这个事件
    else
      if(code==4)then
        activity.setRequestedOrientation(1)
        directbtn1.setVisibility(View.VISIBLE)
        directbtn2.setVisibility(View.GONE)
        if(webView.canGoBack())then--检查网页是否能后退        
          webView.goBack()--如果可以那就后退
          return true--消耗掉这个事件(返回true)
        else
          Toast.makeText(activity,"再按一次返回键将退出", Toast.LENGTH_SHORT )
          .show()
          参数=tonumber(os.time()) 
        end
      end
    end
    return true 
  end
end