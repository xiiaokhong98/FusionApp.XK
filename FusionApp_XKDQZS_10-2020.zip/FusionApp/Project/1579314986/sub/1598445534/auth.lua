require "import"
import "com.androlua.Http"
import "android.text.Html"
import "android.graphics.Typeface"
import "android.graphics.drawable.ColorDrawable"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "json"
import "milkpotatoes"
import "getcode"

appid = ...

activity.setTheme(android.R.style.Theme_Material_Light)
activity.setContentView("auth_layout")
activity.setTitle("激活")

function onKeyDown(code, event)
  if code == 4 then
    return true
  end
end

pics = {
  correct = tostring(activity.getLuaDir("src")).."/correct.png";
  incorrect = tostring(activity.getLuaDir("src")).."/incorrect.png";
}
steps = {
  {
    forward = "取消";
    next = "验证";
    message = "该子页面，需要激活成功后才能体验\n现在，请在下面的输入框中输入您的激活码，并点击验证以继续。稍后，系统将验证您的激活码是否有效。";
    gravity = Gravity.TOP;
    hide = {checking, status, arrow_left};
    show = {forward_step, next_step, arrow_right, message, auth_code, get_code}
  };
  {
    forward = "上一步";
    next = "验证中";
    message = "正在验证您的激活码是否有效，请稍后......";
    gravity = Gravity.CENTER;
    hide = {status, arrow_right, auth_code, get_code};
    show = {forward_step, checking, next_step, arrow_left, message, auth_code, get_code}
  };
  {
    forward = "上一步";
    next = "完成";
    message = "";
    gravity = Gravity.CENTER;
    hide = {checking, arrow_right, auth_code, get_code};
    show = {status, next_step, forward_step, arrow_left, message}
  };
}

function show_page(page)
  local step = steps[page]
  forward_step.setText(step.forward)
  next_step.setText(step.next)
  message.setText(step.message)
  message.getParent().setGravity(step.gravity)
  for k, v in ipairs(step.show) do
    v.setVisibility(View.VISIBLE)
  end
  for k, v in ipairs(step.hide) do
    v.setVisibility(View.GONE)
  end
end

local page = 1
local auth_status = false
show_page(page)

function get_code.onClick(v)
  getAuthCode()
end

function forward_step.onClick(v)
  if page == 1 then
    print("激活未完成")
    activity.result{}
    return
  end
  if page == 2 then
    AlertDialog.Builder(activity)
    .setTitle("提示")
    .setMessage("等待时间过长？请检查网络后重试")
    .setNegativeButton("我再等等", nil)
    .setPositiveButton("不等了", {onClick = function(dialog)
        page = page - 1
        show_page(page)
      end})
    .show()
    return
  end
  if page == 3 then
    page = page - 2
    show_page(page)
    return
  end

end

function next_step.onClick(v)
  if page == 1 then
    if auth_code.Text == "" then
      print("请输入激活码后重试")
    else
      page = page + 1
      show_page(page)
      Http.get("https://aus.nowtime.cc/api/query/auth?appid="..tostring(appid).."&code="..Html.escapeHtml(auth_code.Text),
      function(code, content)
        if code == 200 then
          local content = json.decode(content)
          if page == 2 then
            page = page + 1
            show_page(page)
            if content.code == 200 then
              if content.status == 1 then
              if content["expire_date"] < os.time() then
                message.setText("您的激活码正确，但激活码已过期！")
                status.setImageBitmap(loadbitmap(pics.incorrect))
              else
                forward_step.getParent().setVisibility(View.GONE)
                message.setText("激活码正确，激活成功！现在，点击完成以体验")
                status.setImageBitmap(loadbitmap(pics.correct))
                auth_status = true
                end
              else
                message.setText("您的激活码正确，但激活码被停用！")
                status.setImageBitmap(loadbitmap(pics.incorrect))
              end
            else
              message.setText(content.msg)
              status.setImageBitmap(loadbitmap(pics.incorrect))
            end
          end
        end
      end)
    end
    return 
  end
  if page == 3 then
    if auth_status then
      putData("milkpotatoes", "authcode", auth_code.Text)
      activity.finish()
    else
      print("激活失败")
      activity.result{}
    end
  end
end
