--蓝奏云直链解析
--监听webview加载网页事件获取直链地址

--文件缓存路径
下载目录=Environment.getExternalStorageDirectory().toString().."/"

--整体布局
lanzou={
  LuaWebView;
  id="蓝奏解析";
  Visibility='invisible';--隐藏控件
}; 

webView.addView(loadlayout(lanzou))

function 安装软件(安装包路径)
  import"java.net.URLDecoder"
  intent = Intent(Intent.ACTION_VIEW)
  intent.setDataAndType(安装包路径, "application/vnd.android.package-archive")
  intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  activity.startActivity(intent)
end

function xdc(url,path)
  require"import"
  import"java.net.URL"
  local ur =URL(url)
  import"java.io.File"
  file =File(path);
  local con = ur.openConnection();
  -- con.setRequestProperty("User-Agent","Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)")
  -- con.setRequestProperty("Host","streamoc.music.tc.qq.com")
  -- con.setRequestProperty("Connection","keep-alive")
  -- con.setRequestProperty("Accept-Encoding","gzip, deflate")
  local co = con.getContentLength();
  local is = con.getInputStream();
  local bs = byte[1024]
  local len,read=0,0
  import"java.io.FileOutputStream"
  local wj= FileOutputStream(path);
  len = is.read(bs)
  while len~=-1 do
    wj.write(bs, 0, len);
    read=read+len
    pcall(call,"ding",read,co)
    len = is.read(bs)
  end
  wj.close();
  is.close();
  pcall(call,"dstop",co)

end
function appDownload(url,path)
  thread(xdc,url,path)
end

function 软件内下载(title,url,path)
  local ts=true
  local wl=activity.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE).getActiveNetworkInfo();
  if wl== nil then
    print("无法连接到服务器，请检查网络")
  else
    appDownload(url,path)
  end
  local layout={
    LinearLayout;
    orientation='vertical';--纵向或横向
    layout_width='match_parent';--布局宽度
    layout_height='match_parent';--布局高度
    background='drawable/lanzou.png';--背景颜色(图片路径)
    {
      LinearLayout;
      orientation='vertical';--纵向或横向
      layout_width="match_parent";
      layout_height="match_parent";
      layout_gravity="center";--重力属性
      ScrollView,--纵向滑动
      VerticalScrollBarEnabled=false;--隐藏纵向滑条
      layout_marginTop="0dp",
    };
    {
      LinearLayout;
      layout_width="match_parent";
      layout_height="wrap_content";
      orientation="horizontal";
      gravity="center";
      {
        TextView;
        textSize="18sp";
        id="appdowninfo";
        text=title;
        gravity="center";
        textStyle="bold";
        layout_width="match_parent";
        layout_height="wrap_content";
      };
    };
    {
      LinearLayout;
      layout_width="match_parent";
      layout_height="wrap_content";
      orientation="vertical";
      {
        TextView;
        id="appdowninfo";
        text="已经下载：0MB/0MB\n\n下载状态：准备下载...";
        layout_width="match_parent";
        layout_height="wrap_content";
        layout_marginTop="15dp";
        layout_marginRight="15dp";
        layout_marginLeft="15dp";
        layout_marginBottom="15dp";
        textSize="15sp";
      };
      {
        ProgressBar;
        id="进度条";
        progress=0,
        style="?android:attr/progressBarStyleHorizontal";
        layout_width="match_parent";
        layout_height="wrap_content";
        layout_marginTop="15dp";
        layout_marginRight="15dp";
        layout_marginLeft="15dp";
        layout_marginBottom="15dp";
      };
    };
    {
      LinearLayout;
      layout_width="match_parent";
      layout_height="wrap_content";
      orientation="horizontal";
      {
        FrameLayout;
        layout_width="match_parent";
        layout_height="wrap_content";
        layout_weight="1";
        id="openfile";
        visibility=0,
        {
          TextView;
          id="安装";
          text="";
          textColor="#ff53bcf5";
          style="?android:attr/buttonBarButtonStyle";
          layout_width="wrap_content";
          layout_height="wrap_content";
          gravity="center";
          layout_gravity="center";
        };
      };
      {
        FrameLayout;
        layout_width="match_parent";
        layout_height="wrap_content";
        layout_weight="1";
        {
          TextView;
          id="后台下载";
          text="后台下载";
          textColor="#ff53bcf5";
          style="?android:attr/buttonBarButtonStyle";
          layout_width="wrap_content";
          layout_height="wrap_content";
          gravity="center";
          layout_gravity="center";
        };
      };
    };
  };

  dldown=AlertDialog.Builder(activity)
  .setView(loadlayout(layout))
  .show()
  .setCancelable(false)

  进度条.ProgressDrawable.setColorFilter(PorterDuffColorFilter(0xFFFC8BDA,PorterDuff.Mode.SRC_ATOP))

  function ding(a,b)--已下载，总长度(byte)
    appdowninfo.Text="下载进度："..string.format("%0.2f",a/1024/1024).."MB/"..string.format("%0.2f",b/1024/1024).."MB".."\n\n下载状态：正在下载..."
    进度条.progress=(a/b*100)
  end

  function dstop(c)--总长度
    if ts then
      appdowninfo.Text="文件大小："..string.format("%0.2f",c/1024/1024).."MB".."\n\n下载状态：下载完成\n下载目录："..下载目录
      后台下载.setText("关闭")
      安装.setText("安装")
      luajava.clear(ts)

      安装.onClick=function()
        dldown.dismiss()
        安装软件(Uri.parse("file://"..path))
      end
      --print(title.."已下载")
    else
      print(title.."已下载")
      luajava.clear(ts)
    end
  end

  后台下载.onClick=function()
    dldown.dismiss()
    luajava.clear(dldown,布局)
    ts=nil
    if 后台下载.getText()=="后台下载" then
      print("正在下载...")
    end
  end

end


function 蓝奏云直链(geturl)
  if (geturl:find"https://www.lanzous.com") then
    if(geturl:find"www.lanzous.com/tp/")then
    else
      geturl=geturl:gsub("www.lanzous.com/","www.lanzous.com/tp/")
    end
    local header={
      ["Accept-Language"]="zh-CN",
      ["Referer"]="https://www.lanzous.com",
      ["User-Agent"]="Mozilla/5.0 (Linux; U; Android 6.0.1; zh-cn; OPPO R9s Plus Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/53.0.2785.134 Mobile Safari/537.36 OppoBrowser/4.9.3"
    }
    Http.get(geturl,nil,nil,header,function(code,content,cookie,header)
      if(code==200 and content)then
        if(content=="")then
          print("请检查此蓝奏云链接是否正确")
        else
          if String(content).contains("来晚啦...文件取消分享了") then
            print("来晚啦...文件取消分享了")
          else
            if String(content).contains("输入密码") then
              print("此蓝奏云链接有密码，无法解析抱歉")
            else
              if String(content).contains("时间:") then
                发布者=content:match('<span class="mt2">发布者:</span>(.-)<span')
                文件名称=content:match("<title>(.-)</title>")
                文件大小=content:match('<span class="mtt">. (.-) .</span>')
                发布时间=content:match('<span class="mt2">时间:</span>(.-)<span')
                --判断蓝奏云规则是否更改
                if String(content).contains("'https") then
                  蓝奏直链="https"..content:match("'https(.-)';").."?"..content:match("'%?(.-)';")
                else
                  蓝奏直链="https"..content:match('"https(.-)";').."?"..content:match('"%?(.-)";')
                end
                蓝奏解析.loadUrl(蓝奏直链)
                蓝奏解析.setWebViewClient{
                  onPageStarted=function(view,url,favicon)
                    if(url:find"development(.-)baidupan.com" or url:find"dev(.-)pujirc.com" or url:find"developer(.-)baidupan.com")then 
                      蓝奏解析.stopLoading()
                      停止加载() 
                      if 下载目录~=nil then
                        local path=下载目录..文件名称
                        对话框()
                        .设置标题("请选择下载方式：")
                        .设置消息("发布者: "..发布者.."\n文件名称: "..文件名称.."\n文件大小: "..文件大小.."\n发布时间: "..发布时间.."\n\n下载地址: "..url)

                        .设置积极按钮("在线下载",function()
                          软件内下载(文件名称,url,path)
                        end)

                        .设置中立按钮("ADM下载",function()
                          if pcall(function() activity.getPackageManager().getPackageInfo("com.dv.adm.pay",0) end) then
                            this.startActivity(Intent().setAction("android.intent.action.SEND").setType("text/*").putExtra("android.intent.extra.TEXT", url).setClassName("com.dv.adm.pay","com.dv.adm.pay.AEditor"));
                          else
                            Toast.makeText(activity,"你没有安装ADM...." , Toast.LENGTH_SHORT ).show()
                          end
                        end)

                        .设置消极按钮("浏览器下载",function()
                          import "android.content.*"
                          import "android.net.*"
                          intent = Intent()
                          intent.setAction("android.intent.action.VIEW")
                          content_url = Uri.parse(url)
                          intent.setData(content_url)
                          choose= Intent.createChooser(intent, "选择浏览器打开")
                          activity.startActivity(choose)
                        end)
                        .显示()
                      end
                    end
                  end}
              else
                发布者=content:match('<span class="mt2">发布者:</span>(.-)<span')
                文件名称=content:match("<title>(.-)</title>")
                文件大小=content:match('<span class="mtt">. (.-) .</span>')
                --判断蓝奏云规则是否更改
                if String(content).contains("'https") then
                  蓝奏直链="https"..content:match("'https(.-)';").."?"..content:match("'%?(.-)';")
                else
                  蓝奏直链="https"..content:match('"https(.-)";').."?"..content:match('"%?(.-)";')
                end
                蓝奏解析.loadUrl(蓝奏直链)
                蓝奏解析.setWebViewClient{
                  onPageStarted=function(view,url,favicon)
                    if(url:find"development(.-)baidupan.com" or url:find"dev(.-)pujirc.com" or url:find"developer(.-)baidupan.com")then 
                      蓝奏解析.stopLoading()
                      停止加载() 
                      if 下载目录~=nil then
                        local path=下载目录..文件名称
                        对话框()
                        .设置标题("请选择下载方式：")
                        .设置消息("发布者: "..发布者.."\n文件名称: "..文件名称.."\n文件大小: "..文件大小.."\n\n下载地址: "..url)

                        .设置积极按钮("软件内下载",function()
                          软件内下载(文件名称,url,path)
                        end)

                        .设置中立按钮("",function()
                          if pcall(function() activity.getPackageManager().getPackageInfo("com.dv.adm.pay",0) end) then
                            this.startActivity(Intent().setAction("android.intent.action.SEND").setType("text/*").putExtra("android.intent.extra.TEXT", url).setClassName("com.dv.adm.pay","com.dv.adm.pay.AEditor"));
                          else
                            Toast.makeText(activity,"你没有安装ADM...." , Toast.LENGTH_SHORT ).show()
                          end
                        end)

                        .设置消极按钮("浏览器下载",function()
                          import "android.content.*"
                          import "android.net.*"
                          intent = Intent()
                          intent.setAction("android.intent.action.VIEW")
                          content_url = Uri.parse(url)
                          intent.setData(content_url)
                          choose= Intent.createChooser(intent, "选择浏览器打开")
                          activity.startActivity(choose)
                        end)
                        .显示()
                      end
                    end
                  end} 
              end
            end
          end
        end
      else
        if(code==-1)then
          Toast.makeText(activity,"您无法连接网络，请检查您的网络设置" , Toast.LENGTH_SHORT ).show()
        else
          Toast.makeText(activity,"网络请求失败".." "..code , Toast.LENGTH_SHORT ).show()
        end
      end
    end)
  else
    print("请输入正确的蓝奏云分享链接")
  end
end